@echo off
chcp 65001 >nul
setlocal
pushd "%~dp0" || exit /b 1
if not exist "众神搬家.exe" (
  echo 请先完整解压试玩包，再双击开始试玩。
  pause
  exit /b 1
)
set "APPDATA=%CD%\运行数据"
set "LOCALAPPDATA=%CD%\运行数据"
set "TEMP=%CD%\运行数据\临时"
set "TMP=%TEMP%"
if not exist "%TEMP%" mkdir "%TEMP%"
start "" "%CD%\众神搬家.exe"
set "game_status=%errorlevel%"
popd
exit /b %game_status%
